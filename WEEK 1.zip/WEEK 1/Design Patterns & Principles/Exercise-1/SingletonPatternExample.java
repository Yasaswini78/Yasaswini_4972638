public class SingletonPatternExample{
    public static void main(String[] args){
        logger obj1 = logger.getInstance();
        logger obj2 = logger.getInstance();
        obj1.log("obj1: This is a log message.");
        obj1.log("obj2: This is another log message.");
        if (obj1==obj2){
            System.out.println("both obj1 and obj2 are same Instances");
        }
        else{
            System.out.println("obj1 and obj2 are different Instances");
        }
    }
}
class logger{
    static logger obj = new logger();
    private logger(){

    } 
    public static logger getInstance(){
        return obj;
    }
    public void log(String message) {
        System.out.println(message);
    }
}