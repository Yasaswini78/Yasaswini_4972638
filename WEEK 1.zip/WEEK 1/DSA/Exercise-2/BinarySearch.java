import java.util.Arrays;
import java.util.Comparator;

class BinarySearch {
    public static Item searchByItemName(Item[] items, String itemName) {
        Arrays.sort(items, Comparator.comparing(Item::getItemName));
        int left = 0, right = items.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = items[mid].getItemName().compareToIgnoreCase(itemName);
            if (comparison == 0) {
                return items[mid];
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }
}
