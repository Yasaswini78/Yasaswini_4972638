public class EcommerceSearch {
    public static void main(String[] args) {
        Item[] items = {
            new Item("I001", "Watch", "Electronics"),
            new Item("I002", "Smartphone", "Electronics"),
            new Item("I003", "Shirt", "Apparel"),
            new Item("I004", "Book", "Books"),
            new Item("I005", "Tablet", "Electronics")
        };

        // Linear Search
        Item foundItem = LinearSearch.searchByItemName(items, "Shirt");
        if (foundItem != null) {
            System.out.println("Linear Search Found: " + foundItem);
        } else {
            System.out.println("Linear Search: Item not found.");
        }

        // Binary Search
        foundItem = BinarySearch.searchByItemName(items, "Shirt");
        if (foundItem != null) {
            System.out.println("Binary Search Found: " + foundItem);
        } else {
            System.out.println("Binary Search: Item not found.");
        }
    }
}
