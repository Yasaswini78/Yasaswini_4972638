class Item {
    private String itemId;
    private String itemName;
    private String category;

    public Item(String itemId, String itemName, String category) {
        this.itemId = itemId;
        this.itemName = itemName;
        this.category = category;
    }

    public String getItemId() {
        return itemId;
    }

    public String getItemName() {
        return itemName;
    }

    public String getCategory() {
        return category;
    }

    @Override
    public String toString() {
        return "ItemID: " + itemId + ", Name: " + itemName + ", Category: " + category;
    }
}
