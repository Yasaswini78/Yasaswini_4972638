public class EmployeeManagementSystem {
    public static void main(String[] args) {
        EmployeeManager manager = new EmployeeManager();

        // Adding employees
        manager.addEmployee(new Employee("E001", "Swetha", "HR", "Manager", 75000));
        manager.addEmployee(new Employee("E002", "vinki", "Engineering", "Developer", 65000));
        manager.addEmployee(new Employee("E003", "siva", "Sales", "Salesperson", 50000));

        // Listing all employees
        System.out.println("All Employees:");
        manager.listAllEmployees();

        // Updating an employee's details
        System.out.println("\nUpdating vinki's position and salary:");
        manager.updateEmployee("E002", "Engineering", "Senior Developer", 75000);
        manager.listAllEmployees();

        // Deleting an emSployee
        System.out.println("\nDeleting siva:");
        manager.deleteEmployee("E003");
        manager.listAllEmployees();

        // Retrieving a specific employee's information
        System.out.println("\nDetails of Employee E001:");
        Employee employee = manager.getEmployee("E001");
        if (employee != null) {
            System.out.println(employee);
        } else {
            System.out.println("Employee not found.");
        }
    }
}
