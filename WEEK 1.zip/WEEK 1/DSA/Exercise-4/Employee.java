class Employee {
    private String employeeId;
    private String name;
    private String department;
    private String position;
    private double salary;

    public Employee(String employeeId, String name, String department, String position, double salary) {
        this.employeeId = employeeId;
        this.name = name;
        this.department = department;
        this.position = position;
        this.salary = salary;
    }

    // Getters and Setters for the attributes
    public String getEmployeeId() {
        return employeeId;
    }

    public String getName() {
        return name;
    }

    public String getDepartment() {
        return department;
    }

    public String getPosition() {
        return position;
    }

    public double getSalary() {
        return salary;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Employee [ID=" + employeeId + ", Name=" + name + ", Department=" + department +
               ", Position=" + position + ", Salary=" + salary + "]";
    }
}
